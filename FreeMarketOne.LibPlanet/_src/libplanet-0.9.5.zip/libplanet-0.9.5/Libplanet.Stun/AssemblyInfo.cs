using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Libplanet.Stun.Tests")]
