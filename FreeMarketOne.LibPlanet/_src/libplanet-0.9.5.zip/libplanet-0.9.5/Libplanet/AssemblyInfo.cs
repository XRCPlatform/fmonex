using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Libplanet.Tests")]
[assembly: InternalsVisibleTo("Libplanet.Benchmarks")]
