﻿using System.IO;

namespace WixXmlGenerator.Models
{
    public class Component
    {
        private readonly string _id;

        public Component(string filePath, string sourceDir)
        {
            var fileInfo = new FileInfo(filePath);
            var sourceDirectoryInfo = new DirectoryInfo(sourceDir);
            var parentDirectoryInfo = fileInfo.Directory;
            if (parentDirectoryInfo != null)
            {
                var prefix = string.Empty;
                if (fileInfo.Directory.Parent != null)
                {
                    prefix = fileInfo.Directory.Parent.Name.Replace("-", "_");

                    if (fileInfo.Directory.Parent.Parent != null)
                    {
                        prefix += fileInfo.Directory.Parent.Parent.Name.Replace("-", "_");
                    }
                }

                _id = parentDirectoryInfo.Name == sourceDirectoryInfo.Name 
                    ? fileInfo.Name 
                    : parentDirectoryInfo.Name + "_" + fileInfo.Name;
                _id = prefix + _id.Replace("-", "_");
            }
        }
        public string ToXml()
        {
            var xmlString = "<ComponentRef Id=\"" + _id + "\"/>\n";

            return xmlString;
        }
    }
}
