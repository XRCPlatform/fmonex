﻿using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace WixXmlGenerator.Models
{
    public class Folder
    {
        private readonly DirectoryInfo _directoryInfo;
        private readonly List<Folder> _children;
        
        public Folder(string path, List<Folder> chidren)
        {
            _directoryInfo = new DirectoryInfo(path);
            _children = chidren;
        }

        public string ToXml()
        {
            var xmlString = "";

            var prefix = string.Empty;
            if (_directoryInfo.Parent != null)
            {
                prefix = _directoryInfo.Parent.Name.Replace("-", "_");

                if (_directoryInfo.Parent.Parent != null)
                {
                    prefix += _directoryInfo.Parent.Parent.Name.Replace("-", "_");
                }
            }

            if (_children.Any())
            {
                xmlString += "<Directory Id=\"" + prefix + _directoryInfo.Name.Replace("-", "_") + "FolderId\" Name=\"" + _directoryInfo.Name + "\">\n";
                foreach (var child in _children)
                {
                    xmlString += child.ToXml();
                }
                xmlString += "</Directory>\n";
            }
            else
            {
                xmlString = "<Directory Id=\"" + prefix + _directoryInfo.Name.Replace("-", "_") + "FolderId\" Name=\"" + _directoryInfo.Name + "\"/>\n";
            }

            return xmlString;
        }
    }
}
