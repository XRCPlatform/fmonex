﻿namespace WixXmlGenerator.Statics
{
    public static class Arguments
    {
        public static string SourceDir = "-sourceDir";
        public static string WxsDir = "-wxsPath";
        public static string ProjectName = "-projectName";
        public static string OutputFile = "-outputFile";
    }
}
