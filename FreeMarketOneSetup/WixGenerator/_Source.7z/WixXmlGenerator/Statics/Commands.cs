﻿namespace WixXmlGenerator.Statics
{
    public static class Commands
    {
        public static string Version = "-version";
        public static string Help = "-help";
        public static string Generate = "-generate";
    }
}
